import BlogDetail from "./BlogDetail";
import CategoryPage from "./CategoryPage";
import Home from "./Home";
import SignIn from "./Login";
import SignUp from "./Signup";
import WriterPage from "./WriterPage";

export { BlogDetail, CategoryPage, Home, SignIn, SignUp, WriterPage };
