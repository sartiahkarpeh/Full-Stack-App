export const tbTopFiveData = [
  {
    _id: "bmnfue7643kdfbgyer9",
    img: "https://res.cloudinary.com/djs3wu5bg/image/upload/v1693809205/SOCIALMEDIA/bcrhwho7szx3vbktyrtt.png",
    title: "Fullstack Cloud Media",
    views: 675367,
    cat: "EDUCATION",
    comments: 73658,
    createdAt: "2023-10-05T18:25:44.242Z",
  },
  {
    _id: "bmnfue7dfgdf643kdfbgyer9",
    img: "https://res.cloudinary.com/djs3wu5bg/image/upload/v1693809205/SOCIALMEDIA/bcrhwho7szx3vbktyrtt.png",
    title: "Fullstack Cloud Media",
    views: 675367,
    cat: "EDUCATION",
    comments: 73658,
    createdAt: "2023-10-05T18:25:44.242Z",
  },
  {
    _id: "bmnfue764gfhf3kdfbgyer9",
    img: "https://res.cloudinary.com/djs3wu5bg/image/upload/v1693809205/SOCIALMEDIA/bcrhwho7szx3vbktyrtt.png",
    title: "Fullstack Cloud Media",
    views: 675367,
    cat: "EDUCATION",
    comments: 73658,
    createdAt: "2023-10-05T18:25:44.242Z",
  },
  {
    _id: "bmnfue7fg643kdfbgyer9",
    img: "https://res.cloudinary.com/djs3wu5bg/image/upload/v1683874453/samples/bike.jpg",
    title: "Fullstack Cloud Media",
    views: 675367,
    cat: "CODING",
    comments: 73658,
    createdAt: "2023-10-05T18:25:44.242Z",
  },
  {
    _id: "34554cgbvc",
    img: "https://res.cloudinary.com/djs3wu5bg/image/upload/v1693809205/SOCIALMEDIA/bcrhwho7szx3vbktyrtt.png",
    title: "Fullstack Cloud Media",
    views: 675367,
    cat: "EDUCATION",
    comments: 73658,
    createdAt: "2023-10-05T18:25:44.242Z",
  },
  {
    _id: "345dgfdf54cgbvc",
    img: "https://res.cloudinary.com/djs3wu5bg/image/upload/v1683874453/samples/bike.jpg",
    title: "Fullstack Cloud Media",
    views: 675367,
    cat: "EDUCATION",
    comments: 73658,
    createdAt: "2023-10-05T18:25:44.242Z",
  },
  {
    _id: "34554cg676547bvc",
    img: "https://res.cloudinary.com/djs3wu5bg/image/upload/v1693809205/SOCIALMEDIA/bcrhwho7szx3vbktyrtt.png",
    title: "Fullstack Cloud Media",
    views: 675367,
    cat: "EDUCATION",
    comments: 73658,
    createdAt: "2023-10-05T18:25:44.242Z",
  },
];

export const recentFollowersData = [
  {
    _id: "7945,mnkdfvd",
    name: "James Smith",
    image:
      "https://res.cloudinary.com/djs3wu5bg/image/upload/v1683874453/samples/bike.jpg",
    accountType: "User",
    followers: 76485,
    created_At: "2023-10-05T18:25:44.242Z",
  },
  {
    _id: "7945kjhgnmnkdfvd",
    name: "John Smith",
    image:
      "https://res.cloudinary.com/djs3wu5bg/image/upload/v1683874453/samples/bike.jpg",
    accountType: "Writer",
    followers: 76485,
    created_At: "2023-10-05T18:25:44.242Z",
  },
  {
    _id: "7945kjhgndgfgdmnkdfvd",
    name: "John Smith",
    image:
      "https://res.cloudinary.com/djs3wu5bg/image/upload/v1683874453/samples/bike.jpg",
    accountType: "Writer",
    followers: 76485,
    created_At: "2023-10-19T18:25:44.242Z",
  },
  {
    _id: "7945kjhgndcbvcgfgdmnkdfvd",
    name: "John Smith",
    image:
      "https://res.cloudinary.com/djs3wu5bg/image/upload/v1683874453/samples/bike.jpg",
    accountType: "Writer",
    followers: 76485,
    created_At: "2023-10-05T18:25:44.242Z",
  },
  {
    _id: "7945kjhgndcbvcgfgfhfghdmnkdfvd",
    name: "John Smith",
    image:
      "https://res.cloudinary.com/djs3wu5bg/image/upload/v1683874453/samples/bike.jpg",
    accountType: "Writer",
    followers: 76485,
    created_At: "2023-10-06T18:25:44.242Z",
  },
];
